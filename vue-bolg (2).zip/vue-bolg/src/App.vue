<script setup></script>

<template>
  <div>
    <router-view></router-view>
  </div>
</template>

<style scoped>
/* div {
  background-color: #dcdcdc;
} */
</style>
